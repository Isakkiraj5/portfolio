import ChromePortfolio from "../chrome-portfolio"

export default function Page() {
  return <ChromePortfolio />
}
